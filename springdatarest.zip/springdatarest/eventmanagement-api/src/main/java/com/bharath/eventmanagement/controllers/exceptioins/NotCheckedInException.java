package com.bharath.eventmanagement.controllers.exceptioins;

public class NotCheckedInException extends RuntimeException {

}
