package com.bharath.eventmanagement.controllers.exceptioins;

public class AlreadyCheckedInException extends RuntimeException {

}
